package com.latte22.sw_22_test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.LogRecord;

public class MainActivity extends AppCompatActivity {
    private Intent intent;
    private Toolbar toolbarMain;
    private TextView textMain;
    private TextView textDate;

    private static Handler mHandler ;
    @SuppressLint("StaticFieldLeak")
    public static ProgressBar testProgress;
    public static int value;

    public ProgressBar wProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbarMain = findViewById(R.id.toolbar_main);
        textMain = findViewById(R.id.textView);
        textDate = findViewById(R.id.textDate);
        testProgress = findViewById(R.id.testprogressBar);
        wProgress = findViewById(R.id.wprogressBar);

        textDate.setText(getDate());

        setSupportActionBar(toolbarMain); //툴바를 사용하면 여러 레이아웃을 사용할 수 있기 때문
        //getSupportActionBar().setTitle("Loading.."); //툴바 메인 이름 바뀜
        //액션바 설정하기//
        //액션바 타이틀 변경하기
        getSupportActionBar().setTitle("Life Loading... ⏳");
        //액션바 배경색 변경
        //getSupportActionBar().setBackgroundDrawable(new ColorDrawable(0xFF339999));
        //홈버튼 표시
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        intent = getIntent();
        String colorText = intent.getStringExtra("color");
        if (colorText != null) {
            testProgress.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#"+colorText)));
            //wProgress.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#"+colorText)));
        }

        mHandler = new Handler() {
            @SuppressLint("HandlerLeak")
            @Override
            public void handleMessage(Message msg) {

                textMain = findViewById(R.id.textView);
                testProgress = findViewById(R.id.testprogressBar);

                Percent p = new Percent();
                p.persent();
                double percent = p.testLoading;
//
                String strNumber = String.format("%.1f", percent);
                textMain.setText("Loading... " + strNumber + "%");

                //textMain.setText("Loading... " + p.testLoading + "%");

                value = (int) percent;
//                testProgress.setProgress(value);

//                Log.i("in", Double.toString(percent));

//                intent = getIntent();
//                String colorText = intent.getStringExtra("color");
//
//                Log.i("color", colorText);
//                Calendar cal = Calendar.getInstance() ;
//
//                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
//                String strTime = sdf.format(cal.getTime());
//
//                clockTextView = findViewById(R.id.clock) ;
//                clockTextView.setText(strTime) ;
            }
        };

        class NewRunnable implements Runnable {
            @Override
            public void run() {
                while (true) {

//                    Percent p = new Percent();
//
//                    double percent = p.testLoading;
//
//                    String strNumber = String.format("%f", percent);
//                    textMain.setText("Loading... " + strNumber + "%");
//
//                    int value = (int) percent;
//                    testProgress.setProgress(value);

                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    mHandler.sendEmptyMessage(0);
                }
            }
        }

        NewRunnable nr = new NewRunnable();
        Thread t = new Thread(nr);
        t.start();
    }

//        Thread t = new Thread (new Runnable() {
//            public void run() {
//                // a potentially time consuming task
//                YearPercent yp = new YearPercent();
//                double percent = yp.testLoading;
//
//                String strNumber = String.format("%.6f", percent);
//                textMain.setText("Loading... " + strNumber + "%");
//
//                int value = (int) percent;
//                testProgress.setProgress(value);
//            }
//        });
//        t.start();
//        Percent p = new Percent();
//        p.persent(0,0,0);
//
//        (new Thread(new Runnable()
//        {
//
//            @Override
//            public void run()
//            {
//                while (!Thread.interrupted())
//                    try
//                    {
//                        //Percent p = new Percent();
//                        double percent = p.testLoading;
//                        Thread.sleep(1000);
//                        runOnUiThread(new Runnable() // start actions in UI thread
//                        {
//
//                            @Override
//                            public void run()
//                            {
//
//
//                                String strNumber = String.format("%.6f", percent);
//                                textMain.setText("Loading... " + strNumber + "%");
//
//                                int value = (int) percent;
//                                testProgress.setProgress(value);
//                            }
//                        });
//                    }
//                    catch (InterruptedException e)
//                    {
//                        // ooops
//                    }
//            }
//        })).start();

//        mHandler = new Handler() {
//            @Override
//            public void handleMessage(Message msg) {
//
//                YearPercent yp = new YearPercent();
//                double percent = yp.testLoading;
//
//                String strNumber = String.format("%.6f", percent);
//                textMain.setText("Loading... " + strNumber + "%");
//
//                int value = (int) percent;
//                testProgress.setProgress(value);
//            }
//        };
//
//        class NewRunnable implements Runnable {
//            @Override
//            public void run() {
//                while (true) {
//                    try {
//                        Thread.sleep(1000);
//                    } catch (Exception e) {
//                        e.printStackTrace() ;
//                    }
//                    //mHandler.sendEmptyMessage(0) ;
//                    mHandler.getEncoding();
//                }
//            }
//        }
//
//        NewRunnable nr = new NewRunnable() ;
//        Thread t = new Thread(nr) ;
//        t.start() ;

        // 현재 날짜 일 수 / 365 (년도 총 일 수) * 100
        //testLoading = (YearPercent)getApplicationContext();

//        String strNumber = String.format("%.6f", testLoading);
//        textMain.setText("Loading... " + strNumber + "%");

        //Part 1 : toolbar, FloatingActionButton (+Snackbar)
//        setSupportActionBar(toolbarMain); //툴바를 사용하면 여러 레이아웃을 사용할 수 있기 때문
//        getSupportActionBar().setTitle("Loading.."); //툴바 메인 이름 바뀜

//        int value = (int) testLoading;
//        testProgress.setProgress(value);

//        wProgress = findViewById(R.id.progressBar);
//        wProgress.setProgress(value);

//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //뒤로가기 버튼 실행 어떻게 받아야 하는지
    //툴바에서 클릭되면 이게 실행됨
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_test_01:
                Intent subIntent = new Intent(this, SubActivity.class);
                startActivity(subIntent);
//                Toast.makeText(this, "text 01", Toast.LENGTH_SHORT).show();
                break;
//
            case R.id.action_test_02:
                Intent thirdIntent = new Intent(this, ThirdActivity.class);
                startActivity(thirdIntent);
//                Toast.makeText(this, "text 02", Toast.LENGTH_SHORT).show();
                break;
//
            case R.id.action_test_03:
                Percent p = new Percent();
                Percent.tf = true;
                Percent.dday_static = (long) 0.0;
                testProgress.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#4C66F4")));
                Log.i("tf","true");
                //Toast.makeText(this, "text 03", Toast.LENGTH_SHORT).show();
                break;
//            case android.R.id.home :
//                finish();
    }
        return super.onOptionsItemSelected(item);
    }

    private String getDate() {
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일");
        String getDate = dateFormat.format(date);

        return getDate;
    }

//    private long getYear(){
//        Calendar calendar;
//        calendar = Calendar.getInstance();
//        int year = calendar.get(Calendar.YEAR);
//
//        if (year % 400 == 0) {  //연도가 400의 배수이면 윤년
//            return 366;
//        } else if (year % 4 == 0 && year % 100 != 0) {  //연도가 4의 배수고 100의 배수가 아니면 윤년
//            return 366;
//        } else {  //나머지는 다 윤년이 아니다
//            return 365;
//        }
//    }
//
//    private double getRemainingDays(){
//
////        try {
////            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
////            Date date = dateFormat.parse(getDate());
////
////            long d1 = getYear() - date.getTime();
////            long remain = d1/(1000*60*60*24);
////            if(remain < 0) remain += 1;
////
////
////
////            return remain;
////
////        } catch (ParseException e) {
////            return -2;
////        }
//        int  d1 = -2;
//
//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
//            OffsetDateTime offset = OffsetDateTime.now();
//            //textView.setText(String.valueOf(offset.getDayOfWeek() + " : " + offset.getDayOfMonth() + " : " + offset.getDayOfYear()));
//            d1 = offset.getDayOfYear();
//        }
//
//        return d1;
//    }
}
