package com.latte22.sw_22_test;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.Calendar;
import java.util.Date;

public class Percent{

    double testLoading;
    //= ((getRemainingDays() /  getYear())*100);
    //YearPercent yp = new YearPercent();

    //testLoading = ((getRemainingDays() /  getYear())*100);

    static boolean tf = true;
    static long dday_static;

    public void persent(long d){
        dday_static = d;
    }

    public void persent(){
        if(tf == true && dday_static == 0.0){
            //testLoading = yp.test;
            //
            //return testLoading;
            testLoading = ((getRemainingDays() /  getYear())*100);
//            Log.i("loading", Double.toString(testLoading));
//            Log.i("loading", Double.toString(getRemainingDays()));
//            Log.i("loading", Double.toString(getYear()));
//            Log.i("tf","true");
        }
        else {
            // dday_static = d;
            testLoading =  (((getYear()-(double)dday_static)/getYear())*100);
//            Log.i("loading", Double.toString(testLoading));
//            Log.i("loading", Double.toString(dday_static));
//            Log.i("loading", Double.toString(getYear()));
            if(testLoading < 0) testLoading = 0;
            //return testLoading;
//            Log.i("tf","false");
        }
        MainActivity.testProgress.setProgress((int)testLoading);
    }

//    public void persent(long t, long d){
//        if(tf == true){
//            //testLoading = yp.test;
//            //
//            //return testLoading;
//            testLoading = ((getRemainingDays() /  getYear())*100);
//            Log.i("tf","true");
//        }
//        testLoading =  (t-d);
//        //return testLoading;
//        Log.i("tf","false");
//    }

//    private String getDate() {
//        long now = System.currentTimeMillis();
//        Date date = new Date(now);
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일");
//        String getDate = dateFormat.format(date);
//
//        return getDate;
//    }

    private long getYear(){
        Calendar calendar;
        calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);

        if (year % 400 == 0) {  //연도가 400의 배수이면 윤년
            return 366;
        } else if (year % 4 == 0 && year % 100 != 0) {  //연도가 4의 배수고 100의 배수가 아니면 윤년
            return 366;
        } else {  //나머지는 다 윤년이 아니다
            return 365;
        }
    }

    private double getRemainingDays(){
        int  d1 = -2;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            OffsetDateTime offset = OffsetDateTime.now();

            d1 = offset.getDayOfYear();
        }

        return d1;
    }
}