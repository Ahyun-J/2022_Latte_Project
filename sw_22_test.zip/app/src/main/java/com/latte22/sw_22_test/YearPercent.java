package com.latte22.sw_22_test;

import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.Calendar;
import java.util.Date;

public class YearPercent {

    double testLoading = ((getRemainingDays() /  getYear())*100);

    private long getYear(){
        Calendar calendar;
        calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);

        if (year % 400 == 0) {  //연도가 400의 배수이면 윤년
            return 366;
        } else if (year % 4 == 0 && year % 100 != 0) {  //연도가 4의 배수고 100의 배수가 아니면 윤년
            return 366;
        } else {  //나머지는 다 윤년이 아니다
            return 365;
        }
    }

    private double getRemainingDays(){
        int  d1 = -2;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            OffsetDateTime offset = OffsetDateTime.now();

            d1 = offset.getDayOfYear();
        }

        return d1;
    }

}
